Solo contengo la carpeta con los datos, el fichero excel por si se quieren ver los datos de forma mas sencilla,
el pdf y el codigo de practica en python.
